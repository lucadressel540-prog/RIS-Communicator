const ACTIVE_BOOKING_KEY = "active-booking";

const jsonHeaders = {
  "Content-Type": "application/json; charset=utf-8",
  "Cache-Control": "no-store",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type"
};

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === "/api/active-booking") {
      return handleActiveBooking(request, env);
    }

    return env.ASSETS.fetch(request);
  }
};

async function handleActiveBooking(request, env) {
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: jsonHeaders });
  }

  if (!env.RIS_STATE) {
    return json(
      {
        error: "Cloudflare KV Binding RIS_STATE fehlt.",
        hint: "Im Pages-Projekt unter Bindungen einen KV-Namensraum mit Variablenname RIS_STATE hinterlegen."
      },
      503
    );
  }

  if (request.method === "GET") {
    const booking = await env.RIS_STATE.get(ACTIVE_BOOKING_KEY, { type: "json" });
    return json({ booking: booking || null });
  }

  if (request.method === "POST") {
    let booking;
    try {
      booking = await request.json();
    } catch {
      return json({ error: "Ungueltiges JSON." }, 400);
    }

    if (!booking || !booking.number) {
      return json({ error: "Buchung ohne Zugnummer." }, 400);
    }

    await env.RIS_STATE.put(
      ACTIVE_BOOKING_KEY,
      JSON.stringify({
        number: String(booking.number),
        line: booking.line ? String(booking.line) : "",
        role: booking.role ? String(booking.role) : "",
        dateKey: booking.dateKey ? String(booking.dateKey) : "today",
        bookedAt: booking.bookedAt || new Date().toISOString()
      })
    );

    return json({ ok: true });
  }

  if (request.method === "DELETE") {
    await env.RIS_STATE.delete(ACTIVE_BOOKING_KEY);
    return json({ ok: true });
  }

  return json({ error: "Method not allowed." }, 405);
}

function json(payload, status = 200) {
  return new Response(JSON.stringify(payload), {
    status,
    headers: jsonHeaders
  });
}
