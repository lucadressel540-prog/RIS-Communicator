const screens = {
  splash: document.getElementById("splash"),
  home: document.getElementById("home"),
  search: document.getElementById("searchPage"),
  journey: document.getElementById("journeyPage"),
  safety: document.getElementById("safetyPage"),
  editor: document.getElementById("editorPage")
};

const searchForm = document.getElementById("searchForm");
const trainSearch = document.getElementById("trainSearch");
const searchResult = document.getElementById("searchResult");
const clearButton = document.querySelector("[data-action='clear-search']");
const roleSheet = document.getElementById("roleSheet");
const roleText = document.getElementById("roleText");
const routeScroll = document.getElementById("routeScroll");
const journeyTitle = document.getElementById("journeyTitle");
const checkoutButton = document.getElementById("checkoutButton");
const editNumber = document.getElementById("editNumber");
const editLine = document.getElementById("editLine");
const editFrom = document.getElementById("editFrom");
const editTo = document.getElementById("editTo");
const editStops = document.getElementById("editStops");

installImageFallbacks();

const defaultTrain = {
  number: "4865",
  line: "RE2",
  from: "Hof Hbf",
  to: "M\u00fcnchen Hbf",
  duration: "3 h 42 min",
  stops: [
    ["Hof Hbf", "", "14:34", "6a"],
    ["Marktredwitz", "15:01", "15:01", "5"],
    ["Weiden(Oberpf)", "15:41", "15:44", "2"],
    ["Schwandorf", "16:09", "16:10", "4"],
    ["Regensburg Hbf", "16:38", "16:46", "1"],
    ["Eggm\u00fchl", "17:00", "17:01", "2"],
    ["Neufahrn(Niederbay)", "17:11", "17:12", "1"],
    ["Ergoldsbach", "17:15", "17:16", "2"],
    ["Landshut(Bay)Hbf", "17:28", "17:30", "6"],
    ["Moosburg", "17:40", "17:41", "2"],
    ["Freising", "17:50", "17:51", "2"],
    ["M\u00fcnchen Hbf", "18:16", "", "31"]
  ]
};

const dateGroups = [
  { label: "Gestern 16.06.26", key: "yesterday" },
  { label: "Heute 17.06.26", key: "today" },
  { label: "Morgen 18.06.26", key: "tomorrow" }
];

let trains = loadTrains();
let recentBookings = loadRecentBookings();
let currentTrain = trains[0];
let selectedDate = "today";
let lastScreen = "home";
let incidentAnswer = "";

function loadTrains() {
  const saved = window.localStorage.getItem("ris-trains");
  if (!saved) return [defaultTrain];
  try {
    const parsed = JSON.parse(saved);
    return Array.isArray(parsed) && parsed.length ? parsed : [defaultTrain];
  } catch {
    return [defaultTrain];
  }
}

async function loadAppData() {
  try {
    const response = await fetch(`data/trains.json?v=${Date.now()}`, { cache: "no-store" });
    if (!response.ok) return;

    const parsed = await response.json();
    if (!Array.isArray(parsed) || !parsed.length) return;

    trains = parsed
      .map(normalizeTrain)
      .filter((train) => train.number && train.stops.length >= 2);

    if (trains.length) currentTrain = trains[0];
  } catch {
    // Offline/file mode keeps the local editor data or default demo train.
  }
}

function normalizeTrain(train) {
  const stops = Array.isArray(train.stops)
    ? train.stops.map((stop) => [
      String(stop?.[0] || ""),
      String(stop?.[1] || ""),
      String(stop?.[2] || ""),
      String(stop?.[3] || "")
    ]).filter((stop) => stop[0])
    : [];

  return {
    number: String(train.number || "").trim(),
    line: String(train.line || "").trim() || "RE",
    from: String(train.from || stops[0]?.[0] || "").trim(),
    to: String(train.to || stops[stops.length - 1]?.[0] || "").trim(),
    duration: String(train.duration || estimateDuration(stops) || "").trim(),
    stops
  };
}

function saveTrains() {
  window.localStorage.setItem("ris-trains", JSON.stringify(trains));
}

function loadRecentBookings() {
  const saved = window.localStorage.getItem("ris-recent-bookings");
  if (!saved) return [];
  try {
    const parsed = JSON.parse(saved);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function saveRecentBookings() {
  window.localStorage.setItem("ris-recent-bookings", JSON.stringify(recentBookings.slice(0, 8)));
}

function showScreen(name) {
  Object.values(screens).forEach((screen) => screen.classList.add("hidden"));
  screens[name].classList.remove("hidden");
  lastScreen = name === "editor" ? lastScreen : name;
}

function openSearch() {
  trainSearch.value = "";
  trainSearch.closest(".search-field").classList.remove("has-value");
  showScreen("search");
  renderSearchResult();
}

function renderSearchResult() {
  const value = trainSearch.value.trim();
  trainSearch.closest(".search-field").classList.toggle("has-value", value.length > 0);
  screens.search.classList.remove("recent-template");
  clearButton.classList.toggle("hidden", value.length === 0);

  if (!value) {
    renderRecentBookings();
    return;
  }

  const train = trains.find((item) => item.number === value);
  if (!train) {
    searchResult.innerHTML = `
      <div class="empty-state">
        ${emptyTrainIcon()}
        <p>F&uuml;r deine Sucheingabe &bdquo;${escapeHtml(value)}&ldquo; haben wir keinen<br>passenden Zug gefunden</p>
      </div>
    `;
    return;
  }

  currentTrain = train;
  searchResult.innerHTML = `
    <div class="date-list">
      ${dateGroups.map((group) => renderDateGroup(group, group.key === selectedDate)).join("")}
    </div>
  `;
}

function renderRecentBookings() {
  if (!recentBookings.length) {
    screens.search.classList.remove("recent-template");
    searchResult.innerHTML = "";
    return;
  }

  screens.search.classList.add("recent-template");
  const grouped = recentBookings.reduce((result, booking) => {
    if (!result[booking.dayLabel]) result[booking.dayLabel] = [];
    result[booking.dayLabel].push(booking);
    return result;
  }, {});

  searchResult.innerHTML = `
    <section class="recent-list">
      <h2>Zuletzt ge&ouml;ffnet</h2>
      ${Object.entries(grouped).map(([label, bookings]) => `
        <div class="recent-group">
          <p>${escapeHtml(label)}</p>
          ${bookings.map((booking) => `
            <button class="train-badge recent-badge" type="button" data-recent-number="${escapeHtml(booking.number)}" data-recent-date="${escapeHtml(booking.dateKey)}">
              ${trainSvg()} ${escapeHtml(booking.line)} (${escapeHtml(booking.number)})
            </button>
          `).join("")}
        </div>
      `).join("")}
    </section>
  `;
}

function renderDateGroup(group, open) {
  return `
    <section class="date-group">
      <button class="date-title" type="button" data-date="${group.key}">
        <span>${group.label}</span>
        <span>${open ? "&#8963;" : "&#8964;"}</span>
      </button>
      ${open ? renderTrainCard(currentTrain) : ""}
    </section>
  `;
}

function renderTrainCard(train) {
  const first = train.stops[0];
  const last = train.stops[train.stops.length - 1];
  return `
    <button class="result-card" type="button" data-action="open-roles">
      <div class="card-times">
        <b>${first[2] || first[1]}</b>
        <em>${first[2] || first[1]}</em>
        <span>${escapeHtml(train.duration)}</span>
        <b>${last[1] || last[2]}</b>
      </div>
      <div class="mini-route" aria-hidden="true">
        <span class="ring"></span>
        <span class="line"></span>
        <span class="pin"></span>
      </div>
      <div class="card-places">
        <b>${escapeHtml(train.from)}</b>
        <span class="train-badge">${trainSvg()} ${escapeHtml(train.line)} (${escapeHtml(train.number)})</span>
        <b>${escapeHtml(train.to)}</b>
      </div>
    </button>
  `;
}

function openRoleSheet() {
  roleText.innerHTML = `<span class="role-line">Bitte w&auml;hle deine Rolle aus, um dich in den <b>${escapeHtml(currentTrain.line)}</b></span><span class="role-line"><b>(${escapeHtml(currentTrain.number)})</b> einzubuchen</span>`;
  roleSheet.classList.remove("hidden");
}

function closeRoleSheet() {
  roleSheet.classList.add("hidden");
}

function bookRole(role) {
  closeRoleSheet();
  addRecentBooking(currentTrain, selectedDate);
  journeyTitle.textContent = `${currentTrain.line} (${currentTrain.number})`;
  renderRoute(role);
  showScreen("journey");
}

function addRecentBooking(train, dateKey) {
  const dayLabel = dayLabelFor(dateKey);
  recentBookings = recentBookings.filter((booking) => !(booking.number === train.number && booking.dateKey === dateKey));
  recentBookings.unshift({
    number: train.number,
    line: train.line,
    dateKey,
    dayLabel
  });
  saveRecentBookings();
}

function dayLabelFor(dateKey) {
  if (dateKey === "tomorrow") return "Morgen";
  if (dateKey === "yesterday") return "Gestern";
  return "Heute";
}

function renderRoute(role) {
  routeScroll.innerHTML = `
    <ol class="route-list">
      ${currentTrain.stops.map((stop, index) => {
        const isFirst = index === 0;
        const isLast = index === currentTrain.stops.length - 1;
        return `
          <li class="${isFirst ? "first" : ""} ${isLast ? "last" : ""}">
            <span class="route-node"></span>
            <div class="stop-main">
              <b>${escapeHtml(stop[0])}</b>
              ${stop[1] ? `<span>an ${escapeHtml(stop[1])}</span>` : ""}
              ${stop[2] ? `<span>ab ${escapeHtml(stop[2])}</span>` : ""}
            </div>
            <span class="platform">Gl. ${escapeHtml(stop[3])}</span>
          </li>
        `;
      }).join("")}
    </ol>
  `;
  routeScroll.scrollTop = 0;
}

function openSafetyCheck() {
  incidentAnswer = "";
  document.querySelectorAll("input[name='incident']").forEach((input) => {
    input.checked = false;
  });
  checkoutButton.disabled = true;
  checkoutButton.textContent = `Von ${currentTrain.line} (${currentTrain.number}) ausbuchen`;
  showScreen("safety");
}

function handleIncidentChoice(value) {
  incidentAnswer = value;
  checkoutButton.disabled = value !== "no";
}

function checkoutTrain() {
  if (incidentAnswer !== "no") return;
  showScreen("home");
}

function openEditor() {
  const train = trains.find((item) => item.number === trainSearch.value.trim()) || currentTrain || trains[0];
  editNumber.value = train.number;
  editLine.value = train.line;
  editFrom.value = train.from;
  editTo.value = train.to;
  editStops.value = train.stops.map((stop) => stop.join(";")).join("\n");
  showScreen("editor");
}

function saveEditor() {
  const number = editNumber.value.trim();
  const line = editLine.value.trim() || "RE";
  const stops = editStops.value.split("\n")
    .map((row) => row.trim())
    .filter(Boolean)
    .map((row) => {
      const cells = row.split(";").map((cell) => cell.trim());
      return [cells[0] || "Halt", cells[1] || "", cells[2] || "", cells[3] || ""];
    });

  if (!number || stops.length < 2) return;

  const train = {
    number,
    line,
    from: editFrom.value.trim() || stops[0][0],
    to: editTo.value.trim() || stops[stops.length - 1][0],
    duration: estimateDuration(stops),
    stops
  };

  trains = trains.filter((item) => item.number !== number);
  trains.push(train);
  currentTrain = train;
  saveTrains();
  trainSearch.value = number;
  showScreen("search");
  renderSearchResult();
}

function estimateDuration(stops) {
  const start = stops[0][2] || stops[0][1];
  const end = stops[stops.length - 1][1] || stops[stops.length - 1][2];
  if (!start || !end) return "";
  const [sh, sm] = start.split(":").map(Number);
  const [eh, em] = end.split(":").map(Number);
  let minutes = eh * 60 + em - (sh * 60 + sm);
  if (minutes < 0) minutes += 24 * 60;
  const hours = Math.floor(minutes / 60);
  const rest = minutes % 60;
  return `${hours} h ${rest} min`;
}

function trainSvg() {
  return `<img class="badge-train-icon" src="assets/icons/badge-train.png" alt=""><span class="badge-separator" aria-hidden="true"></span>`;
}

function emptyTrainIcon() {
  return `<img class="badge-train-icon" src="assets/icons/train-home.png" alt="">`;
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  }[char]));
}

window.addEventListener("load", async () => {
  await loadAppData();
  window.setTimeout(() => {
    screens.splash.classList.add("hidden");
    screens.home.classList.remove("hidden");
  }, 5000);
});

document.addEventListener("click", (event) => {
  const actionTarget = event.target.closest("[data-action]");
  if (actionTarget) {
    const action = actionTarget.dataset.action;
    if (action === "open-search") openSearch();
    if (action === "back-home") showScreen("home");
    if (action === "back-search") showScreen("search");
    if (action === "open-safety") openSafetyCheck();
    if (action === "close-safety") showScreen("journey");
    if (action === "checkout") checkoutTrain();
    if (action === "clear-search") {
      trainSearch.value = "";
      renderSearchResult();
      trainSearch.focus();
    }
    if (action === "open-roles") openRoleSheet();
    if (action === "close-sheet") closeRoleSheet();
    if (action === "open-editor") openEditor();
    if (action === "close-editor") showScreen(lastScreen || "home");
    if (action === "save-editor") saveEditor();
  }

  const dateButton = event.target.closest("[data-date]");
  if (dateButton) {
    selectedDate = dateButton.dataset.date;
    renderSearchResult();
  }

  const recentButton = event.target.closest("[data-recent-number]");
  if (recentButton) {
    const train = trains.find((item) => item.number === recentButton.dataset.recentNumber);
    if (train) {
      currentTrain = train;
      selectedDate = recentButton.dataset.recentDate || "today";
      trainSearch.value = train.number;
      renderSearchResult();
    }
  }

  const roleButton = event.target.closest("[data-role]");
  if (roleButton) bookRole(roleButton.dataset.role);
});

document.addEventListener("change", (event) => {
  const incidentInput = event.target.closest("input[name='incident']");
  if (incidentInput) handleIncidentChoice(incidentInput.value);
});

searchForm.addEventListener("submit", (event) => {
  event.preventDefault();
  renderSearchResult();
  trainSearch.blur();
});

trainSearch.addEventListener("input", renderSearchResult);

function installImageFallbacks() {
  document.addEventListener("error", (event) => {
    const image = event.target;
    if (!(image instanceof HTMLImageElement) || image.dataset.fallbackIcon === "true") {
      return;
    }

    image.dataset.fallbackIcon = "true";
    image.src = fallbackIconFor(image.getAttribute("src") || "");
  }, true);
}

function fallbackIconFor(src) {
  const name = src.split("/").pop() || "";
  const stroke = "#22252d";
  const muted = "#9aa1ad";

  if (name.includes("db-logo")) {
    return svgData(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 90 58">
        <rect x="5" y="5" width="80" height="48" rx="5" fill="#fff" stroke="#e2001a" stroke-width="6"/>
        <text x="45" y="41" text-anchor="middle" font-family="Arial, sans-serif" font-size="34" font-weight="900" fill="#e2001a">DB</text>
      </svg>`);
  }

  if (name.includes("search")) {
    return svgData(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" stroke="${stroke}" stroke-width="5" stroke-linecap="round">
        <circle cx="27" cy="27" r="17"/>
        <path d="M40 40l15 15"/>
      </svg>`);
  }

  if (name.includes("menu")) {
    return svgData(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" stroke="${stroke}" stroke-width="5" stroke-linecap="round">
        <path d="M14 20h36M14 32h36M14 44h36"/>
      </svg>`);
  }

  if (name.includes("back") || name.includes("logout")) {
    return svgData(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" stroke="${stroke}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round">
        <path d="M30 16L14 32l16 16"/>
        <path d="M16 32h34"/>
      </svg>`);
  }

  if (name.includes("bell")) {
    return svgData(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" stroke="${stroke}" stroke-width="4" stroke-linecap="round" stroke-linejoin="round">
        <path d="M20 45h24"/>
        <path d="M24 45V28a8 8 0 0 1 16 0v17"/>
        <path d="M28 51a5 5 0 0 0 8 0"/>
      </svg>`);
  }

  if (name.includes("meinzug")) {
    return svgData(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" stroke="${muted}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round">
        <path d="M48 20H24L12 32l12 12h24"/>
        <path d="M24 32h26"/>
      </svg>`);
  }

  if (name.includes("zuglauf")) {
    return svgData(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" stroke="${stroke}" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round">
        <path d="M15 18c12 0 10 16 22 16h12"/>
        <path d="M49 34l-7-7M49 34l-7 7"/>
        <path d="M15 46c12 0 10-16 22-16"/>
      </svg>`);
  }

  return svgData(`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" stroke="${stroke}" stroke-width="4" stroke-linecap="round" stroke-linejoin="round">
      <rect x="17" y="8" width="30" height="48" rx="8"/>
      <path d="M24 42h16"/>
      <circle cx="32" cy="49" r="2"/>
    </svg>`);
}

function svgData(svg) {
  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg.trim())}`;
}
